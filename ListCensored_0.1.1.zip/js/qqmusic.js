﻿//基本关键字过滤系统
word = ["爱你","Luv","Love you","Love him","Love her","Love it","this girl","that girl","this boy","that boy","鹿晗","TFBoys","fxxk","BIGBANG","Fuck","吴亦凡","在一起","心跳","天长地久","我爱那","女孩","她","他","陈奕迅","贱","sama","回音哥","阿梨","王极","骚","心率","사","랑","연","애","Sex","Gay","Sxx","可爱","陈粒","翻唱","倾情","爱情","周杰伦","爱人","Love!","L.o.v.e.","live"];
function naive() {
if (document.getElementById("zhida_album")) {document.getElementById("zhida_album").style.display="none";}
list = document.getElementsByTagName("li");
lista = document.getElementsByTagName("div");
donum = 0;
donim = 0;
while (donum < list.length) {
 donim = 0;
 while (donim < word.length) {
  if (list[donum].innerHTML.toUpperCase().search(word[donim].toUpperCase()) > -1 && list[donum].innerHTML.search("song") > -1 ) {
//   list[donum].style.display = "none";
   if (donum%2 == 1) {list[donum].innerHTML = '<div class="songlist__item songlist__item--even"><center style="font-size:24px;padding:0px;margin:6px 0;"><b>应国家“雷霆净网”行动要求，QQ音乐已经禁止本歌曲在校园内播放。</b></center></div>';}
   else {list[donum].innerHTML = '<div class="songlist__item"><center style="font-size:24px;padding:0px;margin:6px 0;"><b>应国家“雷霆净网”行动要求，QQ音乐已经禁止本歌曲在校园内播放。</b></center></div>';}
   console.log("Filtered <li> element [" + donum.toString() + "] by keyword [" + word[donim] + "].");
  }
   donim ++;
 }
 donum ++;
}
donum = 0;
donim = 0;
/* console.log("Done."+ donim.toString() +"/"+ donum.toString()); */}
naive();
setInterval("naive();",1000);