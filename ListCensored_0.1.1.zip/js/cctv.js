﻿//AdBlock
i = document.getElementsByTagName("ins");
donum = 0;
function blockIt() {
 while (donum < i.length) {
  i[donum].style="display:none;margin:0;width:0;height:0;position:absolute;top:-10000px;";
  donum++;
 }
}
o = setInterval("blockIt()",250);